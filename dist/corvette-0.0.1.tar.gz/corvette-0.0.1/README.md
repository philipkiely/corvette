# Corvette

Corvette is a static site generator that creates a directory listing similar to an autoindex.

## Development

Use a virtual environment with requirements.txt